#include <stdio.h>
#include <string.h>
#include <stdlib.h> // random ; malloc
#include <time.h>
#include <math.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include "structures.h"
#include "creation.h"
#include "procedures.h"
#include "mutations.h"

// returns the number of tRNAs of different lengths in an array
int* tRNAs_count (organism* O)
{

	tRNA* current_tRNA;
	current_tRNA = O->tRNAs;
	
	int j = 1; // #tRNA
	int l = 0; // length (number of nucleotides)
	int x;

	int* larray = malloc(12*sizeof(int));
	int i;
	for (i=0;i<12;i++)
		larray[i] = 0;

	while (current_tRNA != NULL)
	{
		x = current_tRNA->length_c;
		l = l+x;
		if (x<10)
			larray[x-1] = larray[x-1]+1;

		current_tRNA = current_tRNA->next;
		j++;
	};

	larray[10]=j; // total number of tRNAs
	larray[11]=l; // total length in nucleotides
	
	return(larray);
}


// this function saves the datas in the plot file and the fasta file.
void show_list_org (list_of_organisms* O_list, FILE* out_file, FILE* plot_file,int num_gen,int store)
{
	int j = 1;
	int i;
	int larray2[10]={0};
	int* temparray;
	float mean_mRNA_l = 0;
	
	organism* current_organism = O_list->head;
	do
	{
		temparray=tRNAs_count(current_organism);
		mean_mRNA_l = mean_mRNA_l + strlen(current_organism->mRNA);
		for (i=0;i<10;i++)
			larray2[i] = larray2[i] + temparray[i];
		if (store==1)
		{
			if (j==1 || j%(max_organisms/2) == 0)
			{
				fprintf(out_file,">G%dO%dF%f\n",num_gen,j,current_organism->fitness);
				fprintf(out_file,"%s\n\n",current_organism->protein);
			}
			j++;
		}
		current_organism = current_organism->next;
		free(temparray);
	}
	while(current_organism != O_list->head);
	
	// enters the number of tRNAs of different lengths in the plot file
	fprintf(plot_file,"%d %f %d %d \%d %d %d %d %d %d %d %d\n",prev_cardinal,mean_mRNA_l/(O_list->cardinal),larray2[0],larray2[1],larray2[2],larray2[3],larray2[4],larray2[5],larray2[6],larray2[7],larray2[8],larray2[9]);

}

// the following "show" functions are used to create the log files only.

int show_tRNA (tRNA* C, FILE* out_file)
{
	fprintf(out_file,"[%s] -> %c\n", (C->codon), (C->amino_acid));
	return 0;
}

int show_organism (organism* O, FILE* out_file)
{
	fprintf(out_file,"mRNA : %s \nList of its tRNAs :\n", O->mRNA );
	tRNA* current_tRNA;
	current_tRNA = O->tRNAs;
	
	int j = 1; // #tRNA

	while (current_tRNA != NULL)	// this loop is here to show the list of the tRNAs
	{
		show_tRNA(current_tRNA,out_file);
		current_tRNA = current_tRNA->next;
		j++;
	};
	fprintf(out_file,"It codes for the protein : %s\n",O->protein);
	fprintf(out_file,"Fitness : %f. (length = %d nucleotides)\n", O->fitness, O->length);
	return 0;
}

void show_list (list_of_organisms* O_list, FILE* out_file)
{
	int j = 1;
	
	organism* current_organism = O_list->head;
	do
	{
		fprintf(out_file,"#%d organism. ",j);
		j++;
		show_organism(current_organism, out_file);
		current_organism = current_organism->next;
	}
	while(current_organism != O_list->head);

}

char* get_info (FILE* informations)
{
	int pos=1;
	while (fgetc(informations)!='\n')
	{
		pos++;
	}
	fseek(informations,-pos,SEEK_CUR);
	char* dat = malloc(pos);
	fgets(dat,pos,informations);
	fgetc(informations);
	return(dat);
}


// initialization for random functions
void init ()
{
	unsigned int iseed = (unsigned int)time(NULL);
	srand (iseed);
	gsl_rng_default_seed=(unsigned int)time(NULL); // 	gsl_rng_env_setup();
	T = gsl_rng_default; // generator type
	rng = gsl_rng_alloc (T); 
}

list_of_organisms* get_organisms (FILE* informations, int n)
{
	int i,j;
	list_of_organisms* saved_gen = malloc(sizeof(list_of_organisms));
	saved_gen->cardinal = 0;
	organism* current_org;
	for (i=0;i<n;i++)
	{
		char* mR = get_info(informations);
		int n_tR = atoi(get_info(informations));
		tRNA* beginning = malloc(sizeof(tRNA));
		tRNA* current_tRNA = beginning;
		for (j=0;j<n_tR;j++)
		{
			char* nuc = get_info(informations);
			char amin = fgetc(informations);
			fgetc(informations);
			int l = atoi(get_info(informations));
			current_tRNA->next = create_tRNA(nuc,amin,l);
			current_tRNA = current_tRNA->next;
		}
		
		current_org = create_organism (mR,beginning->next);
		current_org->protein = get_info(informations);
		current_org->length = atof(get_info(informations));
		current_org->n_tRNAs = atoi(get_info(informations));
		current_org->fitness = atof(get_info(informations));
		add_organism(saved_gen, current_org);
		free(beginning);
	}
	return(saved_gen);
}


// function to get the arguments passed to Codonevo and change the different parameters
void get_args(int argc, char** arv)
{
	int i;
	
		if (argc==1)
	{
		printf("-n name : change the name of simulation to name [%s]\n-O name : opens the simulation name (can be used with the option -g only)\n-b int : sets the number of maximum breeds to int [%d]\n-cm int : sets the starting minimum size of codons to int [%d]\n-ch int : sets the starting maximum size of codons to int [%d]\n-cn int : sets the number of tRNA groups to int [%d]\n-g int : sets the number of generations to int [%d]\n-l int : sets the number of generations before which a log will be saved [%d]\n-m int : sets the starting length of the mRNA to int [%d]\n-o int : sets the maximum number of organisms in a generation to int [%d]\n-s float : sets the standard deviation of the Gaussian distribution to float [%f]\n-d float : sets the mean value of the Gaussian distribution to float [%f]\n-D int : sets the probability of duplication of a tRNA to 1/int [%d]\n-k float : sets the constant k used in the fitness calculation to float [%f]\n",name,breeds,min_tRNA_length,max_tRNA_length,num_tRNA_groups,num_gen,logs,mRNA_length,max_organisms,st_dev,g_mean,p_duplication,konst);
		num_gen = 0;
		}

	for (i = 1; i < argc; i++)
	{

		if (arv[i][0] == '-')
		{

			switch (arv[i][1])
			{

				case 'n':	name = arv[++i];
				break;

				case 'b':	breeds = atoi(arv[++i]);
				break;
				
				case 'c':       if(arv[i][2]=='m')
							min_tRNA_length = atoi(arv[++i]);
						else if(arv[i][2]=='h')
							max_tRNA_length = atoi(arv[++i]);
						else if(arv[i][2]=='n')
							num_tRNA_groups = atoi(arv[++i]);
						break;	

				case 'g':	num_gen = atoi(arv[++i]);
				break;
				
				case 'l':	logs = atoi(arv[++i]);
				break;

				case 'm':	mRNA_length = atoi(arv[++i]);
				break;	

				case 'o':	max_organisms = atoi(arv[++i]);
				break;		

				case 's':	st_dev = atof(arv[++i]);
				break;

				case 'd':	g_mean = atof(arv[++i]);
				break;
						
				case 'D':	p_duplication = atoi(arv[++i]);
				break;
				
				case 'k':	konst = atof(arv[++i]);
				break;

				case 'O':	open = 1;
						name = arv[++i];
				break;

				default:	fprintf(stderr,"Unknown switch %s\n", arv[i]);
			}
		}
	}
}

void save_as (FILE* save_file, list_of_organisms* list_org, char* prot)
{
	int i,j;
	fprintf(save_file,"%d\n",num_gen);
	fprintf(save_file,"%d\n",prev_cardinal);
	fprintf(save_file,"%d\n",breeds);
	fprintf(save_file,"%d\n",min_tRNA_length);
	fprintf(save_file,"%d\n",max_tRNA_length);
	fprintf(save_file,"%d\n",num_tRNA_groups);
	fprintf(save_file,"%d\n",logs);
	fprintf(save_file,"%d\n",mRNA_length);
	fprintf(save_file,"%d\n",max_organisms);
	fprintf(save_file,"%f\n",st_dev);
	fprintf(save_file,"%f\n",g_mean);
	fprintf(save_file,"%d\n",p_duplication);
	fprintf(save_file,"%f\n",konst);
	fprintf(save_file,"%s\n",prot);
	fprintf(save_file,"%f\n",score_max);
	fprintf(save_file,"%f\n",s_avrg);
	fprintf(save_file,"%d\n",list_org->cardinal);
	organism* current_org = list_org->head;
	for (i=0;i<list_org->cardinal;i++)
	{
		fprintf(save_file,"%s\n",current_org->mRNA);
		fprintf(save_file,"%d\n",current_org->n_tRNAs);
		tRNA* current_tRNA = current_org->tRNAs;
		for (j=0;j<current_org->n_tRNAs;j++)
		{
			fprintf(save_file,"%s\n",current_tRNA->codon);
			fprintf(save_file,"%c\n",current_tRNA->amino_acid);
			fprintf(save_file,"%d\n",current_tRNA->length_c);
			current_tRNA = current_tRNA->next;
		}
		fprintf(save_file,"%s\n",current_org->protein);
		fprintf(save_file,"%d\n",current_org->length);
		fprintf(save_file,"%d\n",current_org->n_tRNAs); // already written
		fprintf(save_file,"%f\n",current_org->fitness);
	}
}

int main(int argc, char** argv)
{
	
	get_args(argc,argv);
	list_of_organisms* current_gen;
	init(); //init for random functions
	FILE *out;
	FILE *plot;
	FILE *out_d;
	FILE* save;
	char* first_protein;
	int now;
	
	// generation of the output files names
	strcpy(out_name,"out_");
	strcat(out_name,name);
	strcat(out_name,".fa");
	strcpy(out_d_name,"log_");
	strcat(out_d_name,name);
	strcat(out_d_name,".txt");
	strcpy(plot_name,"plot_");
	strcat(plot_name,name);
	strcat(plot_name,".dat");
	strcpy(save_name,"save_");
	strcat(save_name,name);
	strcat(save_name,".txt");

// if the simulation is a new one
	if (open == 0)
	{
		out = fopen(out_name, "w");
		out_d = fopen(out_d_name, "w");
		plot = fopen(plot_name, "w");
		save = fopen(save_name, "w");
		
		now=0;
	
		//Initialization of the organism
		
		
		// /!\ the "real" tRNAs are in first_tRNAs->next ; first_tRNAs is here to prevent re-calculating the length of all the codons for it is stored in first_tRNAs->length_c
		tRNA* first_tRNAs = generate_tRNAs();
		char* mR = generate_mRNA(first_tRNAs->next);
		mRNA_length = strlen(mR);
		
		// creation of the first organism
		organism* Org = create_organism(mR,first_tRNAs->next);
		Org->length = mRNA_length + first_tRNAs->length_c;
		Org->n_tRNAs = 20*num_tRNA_groups ;
		Org->protein = generate_protein(Org->mRNA,Org->tRNAs);
		Org->fitness = 1;
		
		first_protein = malloc(sizeof(char)*(mRNA_length+1));
		// the first protein is the reference
		memmove(first_protein,Org->protein,mRNA_length+1);
		protein_length = strlen(first_protein);
		score_max = protein_length*7.5;
		//score_max = protein_length*7;
		
		s_avrg = Org->length;
		
		Org->next = Org;
		Org->prev = Org;
	
		// creation of the first generation
		list_of_organisms* first_gen = malloc(sizeof(list_of_organisms));
		first_gen->head = Org;
		first_gen->tail = Org;
		first_gen->cardinal = 1;
		
	//end of initialization
		
		current_gen = first_gen;
		fprintf(plot, "new_borns mRNA_length length_1 length_2 length_3 length_4 length_5 length_6 length_7 length_8 length_9 length_10\n");
		show_list_org(current_gen,out,plot,1,1);
		show_list(current_gen,out_d);
	}
// if the simulation is the continuation of an existing one
	
	else if (open==1)
	{
		out = fopen(out_name, "a");
		out_d = fopen(out_d_name, "a");
		plot = fopen(plot_name, "a");
		save = fopen(save_name,"r+");

		now = atoi(get_info(save));
		num_gen = now + num_gen;
		prev_cardinal = atoi(get_info(save));
		breeds = atoi(get_info(save));
		min_tRNA_length = atoi(get_info(save));
		max_tRNA_length = atoi(get_info(save));
		num_tRNA_groups = atoi(get_info(save));
		logs = atoi(get_info(save));
		mRNA_length = atoi(get_info(save));
		max_organisms = atoi(get_info(save));
		st_dev = atof(get_info(save));
		g_mean = atof(get_info(save));
		p_duplication = atoi(get_info(save));
		konst = atof(get_info(save));
		first_protein = get_info(save);
		score_max = atof(get_info(save));
		s_avrg = atof(get_info(save));
		int num_org = atoi(get_info(save));
		current_gen = get_organisms(save,num_org);
	}

	int t1 = (int)time(NULL); // the time when the simulation begins (used to time the computation)

	int j;
	for (j=now;j<num_gen;j++)
	{

			current_gen = next_generation(current_gen,first_protein);
			if (current_gen->cardinal == prev_cardinal)
			{
				j = num_gen+1;
				printf("The organisms stopped reproducing\n");
				break;
			}
			prev_cardinal = current_gen->cardinal; // allows to write the number of new borns in plot_file
			prune(current_gen);
			printf("New generation. #%d\n",j+1);
			show_list_org(current_gen,out,plot,j+1,(1+j)%100);
			prev_cardinal = current_gen->cardinal;
			if (j%logs == 0)
				show_list(current_gen,out_d);
	}
	

	//save_as(save,current_gen,first_protein);
	
	fclose(out);
	fclose(out_d);
	fclose(plot);
	fclose(save);
	
	int t2 = (int)time(NULL);
	printf("It took %d seconds to compute.\n",t2-t1);
	if (open==0)
		free(first_protein);	

	return 0 ;
}
