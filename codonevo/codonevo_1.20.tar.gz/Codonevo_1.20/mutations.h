/* The functions concerning the mutations */

void substitution(organism* Org, int pos)
{
	int mRNA_l = strlen(Org->mRNA); // do not confuse with the constant mRNA_length for the initialization
	char new_nucleotide = nucleotides[rand()%nuc_length];
	if (pos < mRNA_l) // verifies if the mutation occurs in the mRNA...
	{
		while((Org->mRNA)[pos]==new_nucleotide)
		{
			// this loop makes sure the nucleotide substituted is different
			// from the first one
			new_nucleotide = nucleotides[rand()%nuc_length];
		}
		(Org->mRNA)[pos]=new_nucleotide;
	}
	else // or in the tRNAs.
	{
		pos = pos - mRNA_l; // the position in the tRNAs
		tRNA* current_tRNA = Org->tRNAs; // current tRNA is the tRNA being "read"
		int j=1; // j is the number of the current tRNA
		while (pos >= 0)
		{
			int lnuc = current_tRNA->length_c;
			if (lnuc > pos) // comparison between the position and the length of the current tRNA's nucleotide
				{	// to see if we have to step to the next tRNA
					while (current_tRNA->codon[pos]==new_nucleotide)
					{
						// this loop makes sure the nucleotide substituted is different
						// from the first one
						new_nucleotide = nucleotides[rand()%nuc_length];
					}
					current_tRNA->codon[pos]=new_nucleotide;
					pos = -1;
				}
			else
				{
					pos = pos - lnuc;
					current_tRNA = current_tRNA->next;
					j++;
				}
		}
		
	}
}


//function used in the insertion function to insert a char at position pos in a string
char* insert_char (char x, char* word, int pos, int word_l)
{
	char* new_word=(char*)malloc(sizeof(char)*(word_l+2));
	memmove (new_word,word,pos);
	new_word[pos]=x;
	memmove (new_word+pos+1,word+pos,word_l-pos);
	new_word[word_l+1]='\0';
	free(word);
	return (new_word);
}



// Remark : the position in insertion can vary between 0 and length
void insertion(organism* Org, int pos)
{
	int mRNA_l = strlen(Org->mRNA);
	char new_nucleotide = nucleotides[rand()%nuc_length];
	int j,k,lnuc;

	if (mRNA_l > pos)
	{
		Org->mRNA = insert_char(new_nucleotide, Org->mRNA, pos, mRNA_l);
	}
	else
	{
		pos = pos - mRNA_l;
		tRNA* current_tRNA = Org->tRNAs;
		j =1;
		while (pos >= 0)
		{
			lnuc = current_tRNA->length_c;
			if (lnuc==pos) // 1/2 chance to be added at the end of this tRNA or at the beginning of the next tRNA
			{
				k = rand()%2;
				if (k==0)
				{
					if (current_tRNA->next != NULL)
					{
						current_tRNA = current_tRNA->next;
						pos = 0;
						lnuc = current_tRNA->length_c;	
					}
				}

			}
			if (lnuc >= pos)
				{
					current_tRNA->codon=insert_char(new_nucleotide,current_tRNA->codon,pos,lnuc);

					current_tRNA->length_c = lnuc +1;
					pos = -1;
				}
			else
				{
					pos = pos - lnuc;
					current_tRNA = current_tRNA->next;
					j++;
				}
		}
		
	}
}

char* delete_char(char* word, int pos, int word_l)
{
	char* new_word=malloc(sizeof(char)*(word_l));
	memmove (new_word,word,pos);
	memmove (new_word+pos,word+1+pos,word_l-pos);
	free(word);
	return (new_word);
}

void deletion(organism* Org, int pos)
{
	int mRNA_l = strlen(Org->mRNA);
	int lnuc,j;
	if (pos < mRNA_l)
	{
		Org->mRNA=delete_char(Org->mRNA,pos,mRNA_l);
	}
	else
	{
		pos = pos - mRNA_l;
		tRNA* prev_tRNA = NULL;
		tRNA* current_tRNA = Org->tRNAs;
		j=1;
		while (pos >= 0)
		{
			lnuc = current_tRNA->length_c;
			if (lnuc > pos)
				{
					if (lnuc==1 && pos==0)
					{
						if (j == 1)
						{
							Org->tRNAs = current_tRNA->next;
						}
						else if (j>1) prev_tRNA->next = current_tRNA->next;
						free(current_tRNA->codon);
						free(current_tRNA);
						Org->n_tRNAs = Org->n_tRNAs -1;
					}
					else
					{
						current_tRNA->codon=delete_char(current_tRNA->codon,pos,lnuc);
						current_tRNA->length_c = lnuc - 1;
					}
				pos = -1;
				}
			else
				{
					pos = pos - lnuc;
					prev_tRNA = current_tRNA;
					current_tRNA = current_tRNA->next;
					j++;
				}
		}
		
	}
}

void mutation(organism* Org, char* prot)
{
// Remark : postion varies between 0 and length-1 for substitution and deletion, between 0 and length for insertion
// probabilities for insertion and deletion : 1/4 ; probability for substituion : 1/2
	int fortune = rand()%4;
	int position;
	int l = Org->length;
	if (fortune == 2)
	{
		position = rand()%(l+1);
		insertion(Org,position);
		Org->length = l + 1; 
	}
	if (fortune == 3)
	{
		position = rand()%l;
		deletion(Org,position);
		Org->length = l - 1;
	}
	if (fortune == 0 || fortune == 1)
	{
		position = rand()%(Org->length);
		substitution(Org,position);
	}
}

void tRNA_duplication(organism* Org)
{
	int i;
	int r = rand()%Org->n_tRNAs;
	tRNA* current_tRNA = Org->tRNAs;
	for (i=0;i<r;i++)
		current_tRNA = current_tRNA->next;
	tRNA* new_tRNA	= create_tRNA(current_tRNA->codon,current_tRNA->amino_acid,current_tRNA->length_c);
	new_tRNA->next = current_tRNA->next;
	current_tRNA->next = new_tRNA;
	Org->length = Org->length + current_tRNA->length_c;
	Org->n_tRNAs = Org->n_tRNAs + 1;
}

