tRNA* best_tRNA (char* mRNA, tRNA* tRNAs)
{
	float best_score = -100;
	float bonus = 0;
	float score=0;
	int i=0;
	int j=0;
	tRNA* best_tRNAs[20]; // arbitrary choice : there can be only 20 tRNAs with the same score that can be stored
	tRNA* current_tRNA = tRNAs;
	while (current_tRNA != NULL)
	{
		bonus = 1;
		score=0;
		i=0;
		while (((current_tRNA->codon)[i] != '\0') && (mRNA[i] != '\0'))
		{
			if ((current_tRNA->codon)[i]==mRNA[i])
			{
				score = score + bonus;
				bonus = 1.5;
			}
			else
			{
				bonus = 1;
				score = score - 1.5;
			}
			i++;
		}
		if (score > best_score)
		{
			j=0;
			best_score=score;
			best_tRNAs[0]=current_tRNA;
		}
		else if (score == best_score && j<19)
		{
			j++;
			best_tRNAs[j]=current_tRNA;
		}

		current_tRNA = current_tRNA->next;
	}
	return(best_tRNAs[rand()%(j+1)]);
}


// /*
// This function is used during the translation part : it searches the best-fitting protein of an organism
// regarding its mRNA and list of tRNAs
// */

char* generate_protein (char* mRNA, tRNA* tRNAs)
{
	int i=0; //the position in the mRNA 
	int j=0;
	int mRNA_l = strlen(mRNA);
	//a temporary protein is used to store the nucleotides as the translation progresses
	char temp_protein[mRNA_l+1];

	while (i < mRNA_l)
// while the end of the mRNA is not reached we continue looking for the best tRNA coding for this part of the mRNA.
	{
		tRNA* best = best_tRNA(mRNA+i, tRNAs);
		temp_protein[j]= best->amino_acid;
		j++;
		i = i + (best->length_c);
	}
	char* prot = (char*)malloc(sizeof(char)*(j+1));
	memcpy(prot,temp_protein,j);
	prot[j]='\0';
	return(prot);
}


void prune (list_of_organisms* list_org)
{
	organism* current_organism;
	int j,k,r;
	int m = list_org->cardinal;
	int n_kill = m;
	if (m > max_organisms)
	{
		for (j=0;j<m-max_organisms;j++)
		{
			r = rand()%n_kill;
			current_organism = list_org->head;
			for (k=0;k<r;k++)
			{
				current_organism = current_organism->next;
			}
			if (current_organism==list_org->head)
				list_org->head = current_organism->next;
			else if (current_organism == list_org->tail)
				list_org->tail = (list_org->tail)->prev;
			(current_organism->prev)->next = current_organism->next;
			(current_organism->next)->prev = current_organism->prev;
			free_organism(current_organism);
			n_kill--;
		}
	list_org->cardinal = max_organisms;
	}

}

float calculate_fitness(char* reference, char* prot)
{
	float score = 0;
	int j = 0;
	int k = 0;
	int gaps = 0;
	while (!(reference[j] == '\0' || prot[k] == '\0'))
	{
		if (reference[j] == prot[k])
		{
			score = score + 7.5;
		}
		else if (prot[k+1] != '\0' && reference[j] == prot[k+1])
		{
			score = score - 10.0;
			j--;
			gaps++;
		}
		else if (reference[j+1] != '\0' && reference[j+1] == prot[k])
		{
			score = score - 10.0;
			k--;
			gaps--;
		}
		else
		{
			score = score - 1;
		}
		j++;
		k++;
	}
	int dif = strlen(prot);
	gaps = abs(dif - protein_length - gaps);
	if (gaps !=0) // if one of the proteins is shorter than the other (modulated by the number of gaps) the scoring continues
		score = score - 10 - gaps + 1;
	return (score/score_max);
}

