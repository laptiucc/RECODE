# define mm -10
# define ma 7

int open=0;

char nucleotides[] = "1234";
char amino_acids[] = "ABCDEFGHIJKLMNOPQRST";
int aa_length = 20;
int nuc_length = 4;

int max_organisms = 100;
int num_tRNA_groups = 3;
int mRNA_length = 1400;
int breeds = 10;
int num_gen=4000000;
int min_tRNA_length = 8;
int max_tRNA_length = 8;
int logs = 100000;
int p_duplication = 50000;
int prev_cardinal = 0;

char* name = "default";
char out_name[80];
char plot_name[80];
char out_d_name[80];
char save_name[80];

const gsl_rng_type * T;
gsl_rng * rng;
float st_dev = 5; // standard deviation for the normal distribution
float g_mean = 5; // mean value for the normal distribution

int protein_length = 1;
float score_max = 1;
float s_avrg = 1; // used in creation.h : next_generation
float konst=10; // used in creation.h : next_generation

typedef struct tRNA
{
	char* codon;
	char amino_acid;
	int length_c; // length of the codon
	struct tRNA* next;
}tRNA;

typedef struct organism
{
	char* mRNA;
	tRNA* tRNAs;
	char* protein;
	float fitness;
	int length; // ie number of mRNA + tRNAs nucleotides
	int n_tRNAs; // number of tRNAs, used in 'duplicate_tRNA'
	struct organism* prev;
	struct organism* next;
}organism;

typedef struct list_of_organisms
{
	organism* head;
	int cardinal; // used to randomly kill organisms in 'prune'
	organism* tail;
}list_of_organisms;
