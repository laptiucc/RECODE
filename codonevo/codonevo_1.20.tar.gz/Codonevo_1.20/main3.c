#include <stdio.h>
#include <string.h>
#include <stdlib.h> // random
#include <time.h>
// #include <math.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include "structures.h"
#include "creation.h"
#include "procedures.h"
#include "mutations.h"


int show_codon (codon* C)
{
	printf("[%s] -> %c\n", (C->nuc), (C->aa));
	return 0;
}

// int* show_organism (organism* O, FILE* out_file)
// {
// // 	printf("mRNA : %s \nList of its codons :\n", O->mRNA );
// 	codon* current_codon;
// 	current_codon = O->codons;
// 	
// 	int j = 1; // #codon
// 	int l = 0; // length (number of nucleotides)
// 	int x;
// 
// 	int* larray = malloc(10*sizeof(int));
// 	int i;
// 	for (i=0;i<10;i++)
// 		larray[i] = 0;
// 
// 	while (current_codon != NULL)	// this loop is here to show the list of the codons
// 	{
// // 		show_codon(current_codon);
// 		x = strlen(current_codon->nuc);
// 		l = l + x;
// 		if (x<10)
// 			larray[x-1] = larray[x-1]+1;
// 
// 		current_codon = current_codon->next;
// 		j++;
// 	};
// 	float len = l;
// // 	printf("It codes for the protein : %s",O->protein);
// // 	printf("Fitness : %f. Mean-size of codons : %f (length = %d nucleotides)\n", O->fitness,len/j, O->length);
// 	fprintf(out_file,"Fitness : %f. Mean-size of codons : %f (length = %d nucleotides)\n", O->fitness,len/j, O->length);
// 	return(larray);
// }


// returns the number of codons of different lengths in an array
int* codons_count (organism* O)
{

	codon* current_codon;
	current_codon = O->codons;
	
	int j = 1; // #codon
	int l = 0; // length (number of nucleotides)
	int x;

	int* larray = malloc(12*sizeof(int));
	int i;
	for (i=0;i<12;i++)
		larray[i] = 0;

	while (current_codon != NULL)
	{
// 		x = current_codon->length_c;
		x = strlen(current_codon->nuc);
		l = l+x;
		if (x<10)
			larray[x-1] = larray[x-1]+1;

		current_codon = current_codon->next;
		j++;
	};

	larray[10]=j; // total number of codons
	larray[11]=l; // total length in nucleotides
	
	return(larray);
}

void show_list_org (list_of_organisms* O_list, FILE* out_file, FILE* plot_file,int num_gen,int store)
{
	int j = 1;
	int i;
	int larray2[10]={0};
	int* temparray;
	
	organism* current_organism = O_list->head;
	do
	{
		temparray=codons_count(current_organism);
		for (i=0;i<10;i++)
			larray2[i] = larray2[i] + temparray[i];
		if (store==1)
		{
			if (j==1 || j%50 == 0)
			{
				fprintf(out_file,">G%dO%dF%f\n",num_gen,j,current_organism->fitness);
				fprintf(out_file,"%s\n\n",current_organism->protein);
			}
			j++;
		}
		current_organism = current_organism->next;
		free(temparray);
	}
	while(current_organism != O_list->head);
	
	// enters the number of codons of different lengths in the plot file
	fprintf(plot_file,"%d %d \%d %d %d %d %d %d %d %d\n",larray2[0],larray2[1],larray2[2],larray2[3],larray2[4],larray2[5],larray2[6],larray2[7],larray2[8],larray2[9]);

}



int show_codon_detailed (codon* C, FILE* out_file)
{
	fprintf(out_file,"[%s] -> %c\n", (C->nuc), (C->aa));
	return 0;
}

int show_organism_detailed (organism* O, FILE* out_file)
{
	fprintf(out_file,"mRNA : %s \nList of its codons :\n", O->mRNA );
	codon* current_codon;
	current_codon = O->codons;
	
	int j = 1; // #codon

	while (current_codon != NULL)	// this loop is here to show the list of the codons
	{
		show_codon_detailed(current_codon,out_file);
		current_codon = current_codon->next;
		j++;
	};
	fprintf(out_file,"It codes for the protein : %s\n",O->protein);
	fprintf(out_file,"Fitness : %f. (length = %d nucleotides)\n", O->fitness, O->length);
	return 0;
}

void show_list_detailed (list_of_organisms* O_list, FILE* out_file)
{
	int j = 1;
	
	organism* current_organism = O_list->head;
	do
	{
// 		printf("#%d ",j);
		fprintf(out_file,"#%d organism. ",j);
		j++;
		show_organism_detailed(current_organism, out_file);
		current_organism = current_organism->next;
	}
	while(current_organism != O_list->head);

}


// initialization for random functions
void init ()
{
	unsigned int iseed = (unsigned int)time(NULL);
	srand (iseed);
	gsl_rng_default_seed=(unsigned int)time(NULL); // 	gsl_rng_env_setup();
	T = gsl_rng_default; // generator type
	r = gsl_rng_alloc (T); 
}

int header()
{
	char r;
	printf("Name of the simulation ?\n");
	scanf("%as",&name);
	while (getchar() != '\n');
	strcpy(out_name,"out_");
	strcat(out_name,name);
	strcat(out_name,".fa");
	strcpy(out_d_name,"log_");
	strcat(out_d_name,name);
	strcat(out_d_name,".txt");
	strcpy(plot_name,"plot_");
	strcat(plot_name,name);
	strcat(plot_name,".dat");
	printf("Run simulation with default parameters ? (y/n)\n");
	scanf("%c",&r);
	if (r=='y')
		return 0;
	else if (r=='n')
	{
		printf("Enter the number of generations (default = %d) :\n",num_gen);
		scanf("%d",&num_gen);
		printf("Enter the number of maximum breeds (default = %d) :\n",breeds);
		scanf("%d",&breeds);
		printf("Enter the minimum starting length of a codon (default = %d) :\n",min_codon_length);
		scanf("%d",&min_codon_length);
		printf("Enter the maximum starting length of a codon (default = %d) :\n",max_codon_length);
		scanf("%d",&max_codon_length);
		printf("Enter the number of logs you want (default = %d) :\n",num_logs);
		scanf("%d",&num_logs);
		printf("Generate the mRNA from the codons(2) or not(1) :\n");
		scanf("%d",&mRNA_choice);
		return 1;
	}
	else return 2;
}

void get_args(int arc, char** arv)
{
	int i;

	for (i = 1; i < arc; i++)
	{

		if (arv[i][0] == '-')
		{

			switch (arv[i][1])
			{

				case 'n':	name = arv[++i];
				break;

				case 'b':	breeds = atoi(arv[++i]);
				break;
				
				case 'c':       if(arv[i][2]=='m')
						min_codon_length = atoi(arv[++i]);
						else if(arv[i][2]=='h')
							max_codon_length = atoi(arv[++i]);
						else if(arv[i][2]=='n')
							number_of_codons = atoi(arv[++i]);
						break;	

						case 'g':	num_gen = atoi(arv[++i]);
						break;
						
						case 'l':	num_logs = atoi(arv[++i]);
						break;

						case 'm':       if(arv[i][2]=='l')
								mRNA_length = atoi(arv[++i]);
								else if(arv[i][2]=='c')
									mRNA_choice = atoi(arv[++i]);
								break;	
		
								case 'o':	max_organisms = atoi(arv[++i]);
								break;		

								case 's':	st_dev = atof(arv[++i]);
								break;
		
								case 'd':	g_mean = atof(arv[++i]);
								break;

								default:	fprintf(stderr,"Unknown switch %s\n", arv[i]);
			}
		}
	}
}


int main(int argc, char** argv)
{
	
	get_args(argc,argv);
// 	header();
	
	strcpy(out_name,"out_");
	strcat(out_name,name);
	strcat(out_name,".fa");
	strcpy(out_d_name,"log_");
	strcat(out_d_name,name);
	strcat(out_d_name,".txt");
	strcpy(plot_name,"plot_");
	strcat(plot_name,name);
	strcat(plot_name,".dat");
	
	FILE *out;
	FILE *plot;
	FILE *out_d;
	out = fopen(out_name, "w");
	out_d = fopen(out_d_name, "w");
	plot = fopen(plot_name, "w");

	int t1 = (int)time(NULL);
	init(); //init for random functions

//Initialization of the organism
	
	
	// /!\ the "real" codons are in first_cods -> next
	codon* first_cods = generate_codons2();
	
	//create the mRNA
	char* mR;
	if (mRNA_choice==2)
	{
		mR = generate_mRNA2(first_cods->next);
		mRNA_length = strlen(mR);
	}
	else
		mR = generate_mRNA();
	
	// creation of the first organism
	organism* Org = create_organism(mR,first_cods->next);
	Org->length = mRNA_length + first_cods->length_c;
	Org->protein = generate_protein(Org->mRNA,Org->codons);
	Org->fitness = 1;
	
// 	char* first_protein = malloc(sizeof(char)*(mRNA_length+1));
	char* first_protein = calloc(mRNA_length+1,sizeof(char));
	memmove(first_protein,Org->protein,mRNA_length+1);	// the first protein that will be the reference
	protein_length = strlen(first_protein);
	score_max = protein_length*7.5;
	
	Org->next = Org;
	Org->prev = Org;

	// creation of the first generation
	list_of_organisms* first_gen = malloc(sizeof(list_of_organisms));
	first_gen->head = Org;
	first_gen->tail = Org;
	first_gen->cardinal = 1;
	
//end of initialization
	
// 	mutation(Org,first_protein);
// 	show_organism(Org);

	int i,j;
	list_of_organisms* current_gen = first_gen;
	fprintf(plot, "length_1 length_2 length_3 length_4 length_5 length_6 length_7 length_8 length_9 length_10\n");
	show_list_org(current_gen,out,plot,1,1);
	show_list_detailed(current_gen,out_d);
	
	for (j=0;j<num_logs;j++)
	{
		for (i=0;i<num_gen/num_logs;i++)
		{
			current_gen = next_generation(current_gen,first_protein);
			prune2(current_gen);
			printf("New generation. #%d\n",1+i+j*num_gen/num_logs);
			show_list_org(current_gen,out,plot,1+i+j*num_gen/num_logs,(1+i+j*num_gen/num_logs)%100);
// show_list_detailed(current_gen,out_d);
		}
		show_list_detailed(current_gen,out_d);
	}
	
	
	int t2 = (int)time(NULL);
	printf("It took %d seconds to compute.\n",t2-t1);
	
// 	free_list_org(current_gen); //VALGRIND
	free(first_protein);	

	return 0 ;
}
