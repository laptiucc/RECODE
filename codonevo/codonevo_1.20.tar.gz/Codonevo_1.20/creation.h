/*
Here are the functions linked to the creation of the datas
and the ones to free them.
*/


char* generate_protein (char* mRNA, tRNA* tRNAs);
tRNA* best_tRNA (char* mRNA, tRNA* tRNAs);
void mutation(organism* Org, char* prot);
void tRNA_duplication(organism* Org);
float calculate_fitness(char* reference, char* prot);
float calculate_fitness3(char* reference, char* prot);


void free_tRNAs (tRNA* tRNAs)
{
	while(tRNAs != NULL)
	{
		tRNA* next_tRNA = tRNAs->next;
		free(tRNAs->codon);
		free(tRNAs);
		tRNAs = next_tRNA;
	}
}


void free_organism (organism* organ)
{
	free(organ->mRNA);
	free(organ->protein);
	free_tRNAs(organ->tRNAs);
	free(organ); //VaLGRIND
}

void free_list_org (list_of_organisms* list_org)
{
	organism* current_org = list_org->tail;
	organism* next_org;
	do
	{
		next_org = current_org->next;
		free_organism(current_org);
		current_org = next_org;
	}
	while (current_org != list_org->tail);
	free(current_org); //VaLGRIND
	free(list_org);
}

organism* create_organism (char* mR, tRNA* cods)
{	
	organism* org = malloc(sizeof(organism));
	org->mRNA = mR;
	org->tRNAs = cods;
	org->n_tRNAs = 0;
	org->fitness = 0;
	org->length = 0;
	org->prev = NULL;
	org->next = NULL;
	return org;
}


tRNA* create_tRNA (char* nucl, char amin, int length)
{
	char* nucle = malloc(sizeof(char)*(length+1));
	memcpy(nucle,nucl,length+1); // copy the nucleotide because used in replicate
	tRNA* cod = malloc(sizeof(tRNA));
	cod->codon = nucle;
	cod->amino_acid = amin;
	cod->length_c = length;
	cod->next = NULL;
	return cod;	
}


/*
This function generates randomly a list of tRNAs, depending on the mRNA size and the number of tRNAs defined
in the file structure.h
It is only used to initialize the first organism.
*/

tRNA* generate_tRNAs()
{
	int i,j,l,length;
	length = 0;
	tRNA* beginning = malloc(sizeof(tRNA));
	tRNA* current_tRNA = beginning;
	for (i=0;i<num_tRNA_groups*20;i++)
	{
		l = min_tRNA_length + rand()%(max_tRNA_length - min_tRNA_length + 1);
		char nuc[l];
		for (j=0;j<l;j++)
		{
			nuc[j]=nucleotides[rand()%nuc_length];
		}
		nuc[l]='\0';
		char amin = amino_acids[i%20];
		
		current_tRNA->next = create_tRNA(nuc,amin,l);
		current_tRNA = current_tRNA->next;
		length = length + l; // here to store the total length of the tRNAs
	}

	beginning->length_c = length;

	return (beginning);
}


// char* generate_mRNA(tRNA* cods)
// {
// 	int n_tRNAs = 2*mRNA_length/(max_tRNA_length+min_tRNA_length);
// 	char* mR = malloc(sizeof(char)*(n_tRNAs*max_tRNA_length));
// 	int i,j,n_l;
// 	int l=0;
// 	for (i=0;i<n_tRNAs;i++)
// 	{
// 		int x = rand()%(num_tRNA_groups*20);
// 		tRNA* current_tRNA = cods;
// 		for (j=0;j<x;j++)
// 			current_tRNA = current_tRNA->next;
// 		n_l = current_tRNA->length_c;
// 		memcpy(mR+l,current_tRNA->codon,n_l);
// 		l = l + n_l;
//  	}
// 	char* mR2 = malloc(sizeof(char)*(l+1));
// 	memcpy(mR2,mR,l);
// 	mR2[l]='\0';
// 	free(mR);
// 	return(mR2);
// }

char* generate_mRNA(tRNA* cods)
{
	char* temp_mRNA = malloc(sizeof(char)*(mRNA_length+max_tRNA_length));
	int j,n_l;
	int l=0;
	while (l<mRNA_length)
	{
		int x = rand()%(num_tRNA_groups*20);
		tRNA* current_tRNA = cods;
		for (j=0;j<x;j++)
			current_tRNA = current_tRNA->next;
		n_l = current_tRNA->length_c;
		memcpy(temp_mRNA+l,current_tRNA->codon,n_l);
		l = l + n_l;
 	}
	char* mRNA2 = malloc(sizeof(char)*(l+1));
	memcpy(mRNA2,temp_mRNA,l);
	mRNA2[l]='\0';
	free(temp_mRNA);
	return(mRNA2);
}

organism* replicate(organism* Org)
{
	int len = strlen(Org->mRNA)+1;
	char* new_mRNA = malloc(sizeof(char)*len);
	memcpy(new_mRNA,Org->mRNA,len);
	
	tRNA* current_tRNA;
	tRNA* current_new_cod;
	tRNA* new_cod = create_tRNA(Org->tRNAs->codon,Org->tRNAs->amino_acid,Org->tRNAs->length_c);
	current_new_cod = new_cod;
	current_tRNA = (Org->tRNAs)->next;
	while (current_tRNA != NULL)
	{
		current_new_cod->next = create_tRNA(current_tRNA->codon,current_tRNA->amino_acid,current_tRNA->length_c);
		current_tRNA = current_tRNA->next;
		current_new_cod = current_new_cod->next;		
	}
	
	organism* new_org = create_organism(new_mRNA,new_cod);
	new_org->length = Org->length;
	new_org->n_tRNAs = Org->n_tRNAs;
	new_org->next = NULL;
	new_org->prev = NULL;
	new_org->protein = NULL;
	return(new_org);
}

void add_organism(list_of_organisms* list_org, organism* org)
{
	if (list_org->cardinal == 0)
	{
		list_org->head = org;
		list_org->tail = org;
		org->next = org;
		org->prev = org;
	}
	
	organism* current_org = list_org->tail;

	if (org->fitness < list_org->head->fitness)
	{
		while (org->fitness > current_org->fitness)
			current_org = current_org->prev;
	}
	else
	{
		(current_org = list_org->tail);
		list_org->head = org;
	}
	
	(current_org->next)->prev = org;
	org->next = (current_org->next);
	current_org->next = org;
	org->prev = current_org;
	
	if (org->fitness <= list_org->tail->fitness)
	{
		list_org->tail = org;
	}
	
	list_org->cardinal = list_org->cardinal +1;
}



list_of_organisms* next_generation (list_of_organisms* old_generation, char* f_prot)
{
	list_of_organisms* new_gen = malloc(sizeof(list_of_organisms));
	new_gen->cardinal = 0;
	
	organism* current_organism = old_generation->head; // in the old organism list

	organism* norg;
	int i,j,g=0,n=0,rd=0;
	float f;
	
	float new_s_avrg = 0;

	
	do
	{
		organism* next_organism = current_organism->next;
		
		norg = replicate(current_organism);
		norg->protein = generate_protein(norg->mRNA,norg->tRNAs);
		norg->fitness = calculate_fitness(f_prot,norg->protein);
		new_s_avrg = new_s_avrg + norg->length;
		add_organism(new_gen, norg);
		f = current_organism->fitness;
		if (f>0.7)
		{

			n=(int)(((s_avrg+konst*(s_avrg-current_organism->length))/s_avrg)*breeds*(log(2*(f-0.7)/0.3+0.018315)+4)/(4+0.693147));
				//0.018315 = exp(-4) ; 0.693147 = ln(2)
		
			for (i=0;i<n;i++)
			{
				norg = replicate(current_organism);
				double x = gsl_ran_gaussian(rng,st_dev)+g_mean;
				if (x<0)
					g=0;
				else
					g=x/1;
				for (j=0;j<g;j++)
					mutation(norg,f_prot);
				if (norg->tRNAs != NULL)
				{
					rd = rand()%p_duplication;
					if (rd==0)
						tRNA_duplication(norg);
					norg->protein = generate_protein(norg->mRNA,norg->tRNAs);
					norg->fitness = calculate_fitness(f_prot,norg->protein);
					new_s_avrg = new_s_avrg + norg->length;
					add_organism(new_gen, norg);
				}
				else free_organism(norg);
			}
		}
		free_organism(current_organism);
		current_organism = next_organism ; // skip to the next organism in the old list
	}
	while (current_organism != old_generation->head);
	free(old_generation);
        s_avrg = new_s_avrg/(new_gen->cardinal);

	return(new_gen);
 
}



