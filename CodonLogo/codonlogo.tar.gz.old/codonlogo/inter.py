#!/usr/bin/env python


import weblogolib
from corebio.utils.deoptparse import DeOptionParser
import sys


#setup
def blackboxcodonl(inputf,outputf):
  parser = weblogolib._build_option_parser()                

  (opts, args) = parser.parse_args(['--size', 'large', '--composition', 'none', '--fin',inputf,'--fout', outputf])


  if args : parser.error("Unparsable arguments: %s " % args)
  #best not to change anything in the try except block.
  try:
    data = weblogolib._build_logodata(opts)
    format = weblogolib._build_logoformat(data, opts)
    formatter = opts.formatter
    formatter(data, format, opts.fout)
  except ValueError, err :
    print >>sys.stderr, 'Error:', err
    sys.exit(2)
  except KeyboardInterrupt, err:
    sys.exit(0)
  
blackboxcodonl('/home/david/examples/cluster17.aln',"outfile.eps")
