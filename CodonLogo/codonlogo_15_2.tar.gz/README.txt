
CodonLogo (http://recode.ucc.ie/CodonLogo) is a tool for creating sequence 
logos from biological sequence alignments.  It can be run from the command line as a standalone webserver or as a CGI webapp.


For help on the command line interface run
    ./codonlogo --help

To build a simple logo run
    ./codonlogo  < cap.fa > logo.eps


To run as a standalone webserver at localhost:8080 
    ./codonlogo --server


An example file of probabilities is included, examplepriorfile.txt
It can be used with the following command.

    ./codonlogo --prior ./examples/Escherichiacoli.txt < cap.fa > logo.eps


examplepriorfile contains the frequencies for codons in human CDS regions. 


KNOWN ISSUES:

There is a known issue with GPL Ghostscript 9.04 which affects some users which may cause ghostscript to segfault or prevent codonlogos from being generated in anything other than eps format. 

This is believed to be an issue with ghostscript and a bug report has been submitted to the ghostscript mailing list.
This is being investigated. if you encounter this problem it's recommended to downgrade to version 9.01 of ghostscript or earlier .



For converting files to a suitable format the following sites can be used:

http://genome.nci.nih.gov/tools/reformat.html
http://www-bimas.cit.nih.gov/molbio/readseq/




-- Distribution and Modification --
This package is distributed under the new BSD Open Source License. 
Please see the LICENSE.txt file for details on copyright and licensing.
The CodonLogo source code can be downloaded from 
http://recode.ucc.ie/CodonLogo

CodonLogo requires Python 2.6 or 2.7, the corebio python toolkit for
computational biology (http://code.google.com/p/corebio), and the python
array package 'numpy' (http://www.scipy.org/Download)
